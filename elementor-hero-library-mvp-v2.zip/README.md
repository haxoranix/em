# Elementor Hero Library MVP

A static SPA prototype for a modern Elementor Free hero section library.

## What is included

- 10 hero section previews
- Desktop, tablet, and mobile preview modal
- Search and category filtering
- Copy to Elementor button using the native clipboard-style payload
- Download JSON button
- Separate JSON files in `data/elementor-json/`
- No build step required

## How to run locally

Use any static server from the project folder:

```bash
python3 -m http.server 5173
```

Then open:

```txt
http://localhost:5173
```

## How to deploy

### GitHub Pages

Upload the folder contents to a GitHub repository and enable GitHub Pages for the branch.

### Vercel

Import the repository into Vercel. Since this is a static site, no framework preset is required.

## Elementor testing flow

1. Install Elementor Free on a clean WordPress site.
2. Use a compatible theme such as Hello Elementor, Astra, Kadence, GeneratePress, or Blocksy.
3. Make sure Elementor flexbox containers are enabled.
4. Click `Copy to Elementor` for a hero.
5. In Elementor, right-click the canvas or a container and choose `Paste from other site`.
6. Press `Ctrl + V` or `Cmd + V` in the Elementor paste modal.
7. If paste still fails on your Elementor version, use `Download JSON` and import through Elementor templates.

## Important implementation note

The `Copy to Elementor` button writes a clipboard payload shaped like Elementor's native cross-site schema: `type: elementor`, `siteurl`, and `elements`. The downloadable JSON files keep Elementor's documented template structure with `title`, `type`, `version`, `page_settings`, and `content`. Cross-site paste can still fail when the target site has a different Elementor version, disabled container features, blocked clipboard permission, or widget compatibility differences.

## Widget whitelist used in this MVP

- Container
- Heading
- Text Editor
- Image
- Video
- Button
- Icon Box
- Icon List
- Image Carousel
- Counter
- Testimonial
- Social Icons
- Google Maps

## Next product step

After testing the first 10 templates in a clean Elementor Free install, expand the `HEROES` array to 50 sections and add a compatibility badge for each widget set.
